window._CCSettings = {
    platform: "ios",
    groupList: [
        "default",
        "renderTexture",
        "megaSymbol",
        "3DNode",
        "fish",
        "bullet",
        "lazer",
        "groupTop",
        "groupBot",
        "blackHole",
        "lotteryBall1",
        "lotteryBall2",
        "lotteryBall3",
        "lotteryMachine"
    ],
    collisionMatrix: [
        [
            true
        ],
        [
            false,
            false,
            false,
            false
        ],
        [
            false,
            false,
            false
        ],
        [
            false,
            false,
            false,
            false
        ],
        [
            false,
            false,
            false,
            false,
            false,
            true,
            true,
            null,
            null,
            true
        ],
        [
            false,
            false,
            false,
            false,
            true,
            false,
            null,
            null,
            null,
            true
        ],
        [
            false,
            false,
            false,
            false,
            true,
            false,
            false
        ],
        [
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true,
            false
        ],
        [
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true
        ],
        [
            false,
            false,
            false,
            false,
            true,
            true
        ],
        [
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true,
            false,
            false,
            true
        ],
        [
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true,
            false,
            true
        ],
        [
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true,
            true
        ],
        [
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true,
            true,
            true,
            false
        ]
    ],
    rawAssets: {
        assets: {},
        internal: {
            "14TDKXr2NJ6LjvHPops74o": [
                "effects/builtin-2d-gray-sprite.effect",
                "cc.EffectAsset"
            ],
            "0ek66qC1NOQLjgYmi04HvX": [
                "effects/builtin-2d-spine.effect",
                "cc.EffectAsset"
            ],
            "28dPjdQWxEQIG3VVl1Qm6T": [
                "effects/builtin-2d-sprite.effect",
                "cc.EffectAsset"
            ],
            c0BAyVxX9JzZy8EjFrc9DU: [
                "effects/builtin-clear-stencil.effect",
                "cc.EffectAsset"
            ],
            "796vrvt+9F2Zw/WR3INvx6": [
                "effects/builtin-unlit-transparent.effect",
                "cc.EffectAsset"
            ],
            "6dkeWRTOBGXICfYQ7JUBnG": [
                "effects/builtin-unlit.effect",
                "cc.EffectAsset"
            ],
            "6fgBCSDDdPMInvyNlggls2": [
                "materials/builtin-2d-base.mtl",
                "cc.Material"
            ],
            "3ae7efMv1CLq2ilvUY/tQi": [
                "materials/builtin-2d-gray-sprite.mtl",
                "cc.Material"
            ],
            "7a/QZLET9IDreTiBfRn2PD": [
                "materials/builtin-2d-spine.mtl",
                "cc.Material"
            ],
            "ecpdLyjvZBwrvm+cedCcQy": [
                "materials/builtin-2d-sprite.mtl",
                "cc.Material"
            ],
            cffgu4qBxEqa150o1DmRAy: [
                "materials/builtin-clear-stencil.mtl",
                "cc.Material"
            ],
            "2aKWBXJHxKHLvrBUi2yYZQ": [
                "materials/builtin-unlit.mtl",
                "cc.Material"
            ]
        }
    },
    launchScene: "db://assets/slot/cc-chan-7992/R7992.fire",
    scenes: [
        {
            url: "db://assets/slot/cc-chan-7992/R7992.fire",
            uuid: "b0UnxtVRlIw5xCg9KqOsCy"
        },
        {
            url: "db://assets/slot/cc-chan-7992/R7992L.fire",
            uuid: "4a/lH3yENE/5ajP7r35iwy"
        }
    ],
    packedAssets: {},
    md5AssetsMap: {},
    orientation: "landscape",
    debug: true,
    subpackages: {}
};
