import V99SDK from "v99-sdk";


window.__require = function e(o, t, n) {
function s(c, i) {
if (!t[c]) {
if (!o[c]) {
var a = c.split("/");
a = a[a.length - 1];
if (!o[a]) {
var u = "function" == typeof __require && __require;
if (!i && u) return u(a, !0);
if (r) return r(a, !0);
throw new Error("Cannot find module '" + c + "'");
}
}
var p = t[c] = {
exports: {}
};
o[c][0].call(p.exports, function(e) {
return s(o[c][1][e] || e);
}, p, p.exports, e, o, t, n);
}
return t[c].exports;
}
for (var r = "function" == typeof __require && __require, c = 0; c < n.length; c++) s(n[c]);
return s;
}({
Main: [ function(e, o, t) {
"use strict";
cc._RF.push(o, "49205NVZgBOmp1TQlqfT/yI", "Main");
Object.defineProperty(t, "__esModule", {
value: !0
});
var n = cc._decorator, s = n.ccclass, r = n.property, c = function() {
function e() {}
e.CMD_HOME = 1;
e.CMD_TEST = 2;
e.CMD_GET_WALLET = 3;
e.CMD_SIGN = 4;

return e;
}(), i = function(e) {
__extends(o, e);
function o() {
var o = null !== e && e.apply(this, arguments) || this;
o.fish = null;
o.msgTf = null;
o.debugTf = null;
o.text = "hello";
return o;
}
o.prototype.start = function() {
var e = this;
for (var o in sp.spine) console.log("sp.spine === " + o);
cc.sys.isNative;
// var t = window.vjsb;
// t && (t.c2jsMessage = function(o) {
// e.debugTf.string = "c2jsMessage : " + o;
// });
console.log("this.fish ======= 222 " + this.fish);
cc.view.on("canvas-resize", function() {
e.debugTf.string += "\ncocos event: canvas-resize";
e.updateForLandscape();
}, this);
cc.game.on(cc.game.EVENT_HIDE, function() {
e.debugTf.string += "\ncocos event: game_on_hide";
e.updateForLandscape();
});
cc.game.on(cc.game.EVENT_SHOW, function() {
e.debugTf.string += "\ncocos event: game_on_show";
e.updateForLandscape();
});
this.updateForLandscape();
};
o.prototype.updateForLandscape = function() {
console.log("updateForLandscape 3 --- ");
this.node.rotation = 90;
var e = cc.view.getFrameSize();
this.node.scaleY = e.height / e.width;
this.node.scaleX = this.node.scaleY;
};
o.prototype.onHome = function() {
var e = window.vjsb;
console.log("vjsb == " + e);
if (e) {
console.log("on home -- " + e.js2cMessage);
e.js2cMessage(JSON.stringify({
cmd: c.CMD_HOME,
data: {}
}));
}
};
o.prototype.onSend = function() {
    console.log("V99 sdk call");
    var sdk = new V99SDK();
    sdk.getAddress();
};
__decorate([ r(sp.Skeleton) ], o.prototype, "fish", void 0);
__decorate([ r(cc.EditBox) ], o.prototype, "msgTf", void 0);
__decorate([ r(cc.Label) ], o.prototype, "debugTf", void 0);
__decorate([ r ], o.prototype, "text", void 0);
return o = __decorate([ s ], o);
}(cc.Component);
t.default = i;
cc._RF.pop();
}, {} ]
}, {}, [ "Main" ]);